# My Weather App

A Vite + React weather app using Open-Meteo for city search, current conditions, current-location weather, saved searches, unit switching, rain chance, and a 5-day forecast.

## Run Locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

No API key or environment file is required.
