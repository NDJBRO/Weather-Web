param(
  [int]$Port = 4173
)

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Address = [System.Net.IPAddress]::Parse("127.0.0.1")
$Listener = [System.Net.Sockets.TcpListener]::new($Address, $Port)

function Get-ContentType($Path) {
  $Extension = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
  switch ($Extension) {
    ".html" { "text/html; charset=utf-8" }
    ".css" { "text/css; charset=utf-8" }
    ".js" { "text/javascript; charset=utf-8" }
    ".svg" { "image/svg+xml" }
    default { "application/octet-stream" }
  }
}

try {
  $Listener.Start()
  Write-Host "My Weather App is running at http://localhost:$Port/"
  Write-Host "Press Ctrl+C to stop."

  while ($true) {
    $Client = $Listener.AcceptTcpClient()
    try {
      $Stream = $Client.GetStream()
      $Reader = [System.IO.StreamReader]::new($Stream)
      $RequestLine = $Reader.ReadLine()

      while ($Reader.Peek() -ge 0) {
        $Line = $Reader.ReadLine()
        if ([string]::IsNullOrEmpty($Line)) { break }
      }

      $RequestPath = "index.html"
      if ($RequestLine -match "^[A-Z]+\s+([^\s]+)") {
        $RequestPath = [System.Uri]::UnescapeDataString($Matches[1].Split("?")[0].TrimStart("/"))
        if ([string]::IsNullOrWhiteSpace($RequestPath)) {
          $RequestPath = "index.html"
        }
      }

      $FilePath = Join-Path $Root $RequestPath
      $ResolvedRoot = [System.IO.Path]::GetFullPath($Root)
      $ResolvedFile = [System.IO.Path]::GetFullPath($FilePath)
      $Status = "200 OK"
      $ContentType = Get-ContentType $ResolvedFile
      $Bytes = $null

      if (-not $ResolvedFile.StartsWith($ResolvedRoot)) {
        $Status = "403 Forbidden"
        $Bytes = [System.Text.Encoding]::UTF8.GetBytes("Forbidden")
        $ContentType = "text/plain; charset=utf-8"
      }
      elseif (-not (Test-Path -LiteralPath $ResolvedFile -PathType Leaf)) {
        $Status = "404 Not Found"
        $Bytes = [System.Text.Encoding]::UTF8.GetBytes("Not found")
        $ContentType = "text/plain; charset=utf-8"
      }
      else {
        $Bytes = [System.IO.File]::ReadAllBytes($ResolvedFile)
      }

      $Header = "HTTP/1.1 $Status`r`nContent-Type: $ContentType`r`nContent-Length: $($Bytes.Length)`r`nConnection: close`r`n`r`n"
      $HeaderBytes = [System.Text.Encoding]::ASCII.GetBytes($Header)
      $Stream.Write($HeaderBytes, 0, $HeaderBytes.Length)
      $Stream.Write($Bytes, 0, $Bytes.Length)
    }
    finally {
      $Client.Close()
    }
  }
}
finally {
  $Listener.Stop()
}
