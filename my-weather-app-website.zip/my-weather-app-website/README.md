# My Weather App Website

Open this website URL directly:

```text
file:///C:/Users/Nadija/Desktop/Weather%20App/website/index.html
```

Or run the local URL server:

```powershell
powershell -ExecutionPolicy Bypass -File .\start-my-weather-app.ps1
```

Then open:

```text
http://localhost:4173/
```

The site uses Open-Meteo and does not need an API key.

You can also double-click `Open My Weather App.cmd` to start the local server and open the URL automatically.
