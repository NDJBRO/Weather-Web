@echo off
set "APP_DIR=%~dp0"
start "My Weather App Server" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%start-my-weather-app.ps1" -Port 4173
timeout /t 2 /nobreak >nul
start "" "http://localhost:4173/"
