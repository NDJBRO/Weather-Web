import { useEffect, useMemo, useState } from "react";
import {
  Cloud,
  CloudDrizzle,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  Compass,
  Droplets,
  Gauge,
  LocateFixed,
  MapPin,
  RefreshCw,
  Search,
  Sunrise,
  Sunset,
  Sun,
  Wind,
} from "lucide-react";

const APP_NAME = "My Weather App";
const DEFAULT_CITY = "Colombo";
const STORAGE_KEYS = {
  city: "my-weather-app:last-city",
  unit: "my-weather-app:unit",
  recent: "my-weather-app:recent-searches",
};
const popularCities = ["Colombo", "Moscow", "Saint Petersburg", "Kazan", "Sochi", "Novosibirsk"];
const CYRILLIC_PATTERN = /[\u0400-\u04FF]/;

const weatherCodes = {
  0: ["Clear", "Clear sky", Sun],
  1: ["Clear", "Mostly clear", CloudSun],
  2: ["Clouds", "Partly cloudy", CloudSun],
  3: ["Clouds", "Overcast", Cloud],
  45: ["Fog", "Fog", CloudFog],
  48: ["Fog", "Rime fog", CloudFog],
  51: ["Drizzle", "Light drizzle", CloudDrizzle],
  53: ["Drizzle", "Drizzle", CloudDrizzle],
  55: ["Drizzle", "Heavy drizzle", CloudDrizzle],
  61: ["Rain", "Light rain", CloudRain],
  63: ["Rain", "Rain", CloudRain],
  65: ["Rain", "Heavy rain", CloudRain],
  71: ["Snow", "Light snow", CloudSnow],
  73: ["Snow", "Snow", CloudSnow],
  75: ["Snow", "Heavy snow", CloudSnow],
  80: ["Rain", "Rain showers", CloudRain],
  81: ["Rain", "Rain showers", CloudRain],
  82: ["Rain", "Violent showers", CloudRain],
  95: ["Thunderstorm", "Thunderstorm", CloudLightning],
  96: ["Thunderstorm", "Thunderstorm with hail", CloudLightning],
  99: ["Thunderstorm", "Thunderstorm with hail", CloudLightning],
};

const backgrounds = {
  Clear: "from-sky-500 via-cyan-300 to-amber-200",
  Clouds: "from-slate-500 via-sky-300 to-cyan-200",
  Rain: "from-slate-900 via-blue-800 to-cyan-700",
  Drizzle: "from-slate-700 via-blue-500 to-teal-300",
  Snow: "from-sky-100 via-white to-blue-200",
  Thunderstorm: "from-zinc-950 via-violet-950 to-slate-800",
  Fog: "from-slate-400 via-gray-300 to-stone-200",
};

function describeCode(code) {
  return weatherCodes[code] || ["Clouds", "Weather update", CloudSun];
}

function convertTemp(value, unit) {
  return unit === "f" ? value * 1.8 + 32 : value;
}

function formatTemp(value, unit) {
  return `${Math.round(convertTemp(value, unit))}\u00b0${unit.toUpperCase()}`;
}

function formatTime(value) {
  if (!value) return "N/A";
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function formatDateTime(value) {
  if (!value) return "Just now";
  return new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(new Date(value));
}

function getStoredValue(key, fallback) {
  try {
    return window.localStorage.getItem(key) || fallback;
  } catch {
    return fallback;
  }
}

function getStoredRecent() {
  try {
    const value = JSON.parse(window.localStorage.getItem(STORAGE_KEYS.recent) || "[]");
    return Array.isArray(value) ? value.slice(0, 6) : [];
  } catch {
    return [];
  }
}

function rememberSearch(city) {
  const cleanCity = city.trim();
  if (!cleanCity) return;
  try {
    const next = [cleanCity, ...getStoredRecent().filter((item) => item.toLowerCase() !== cleanCity.toLowerCase())].slice(0, 6);
    window.localStorage.setItem(STORAGE_KEYS.recent, JSON.stringify(next));
  } catch {
    // Local storage can be disabled; the app still works without saved searches.
  }
}

async function fetchJson(url, message) {
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 10000);

  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) throw new Error(message);
    return response.json();
  } catch (error) {
    if (error.name === "AbortError") throw new Error("Weather service took too long. Please try again.");
    throw error;
  } finally {
    window.clearTimeout(timeoutId);
  }
}

function hasCyrillic(value) {
  return CYRILLIC_PATTERN.test(value);
}

function scoreGeocodeResult(place, query) {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  const normalizedName = (place.name || "").toLocaleLowerCase();
  let score = 0;

  if (normalizedName === normalizedQuery) score += 20;
  if (normalizedName.startsWith(normalizedQuery)) score += 8;
  if (place.country_code === "RU") score += hasCyrillic(query) ? 12 : 2;
  if (place.admin1) score += 1;

  return score;
}

async function searchPlaces(city, language) {
  const geoUrl = new URL("https://geocoding-api.open-meteo.com/v1/search");
  geoUrl.search = new URLSearchParams({ name: city, count: "10", language, format: "json" });
  const geoData = await fetchJson(geoUrl, "Could not search for that city.");
  return geoData.results || [];
}

async function fetchWeatherByCity(city) {
  const languages = hasCyrillic(city) ? ["ru", "en"] : ["en", "ru"];
  const seen = new Set();
  const places = [];

  for (const language of languages) {
    const results = await searchPlaces(city, language);
    results.forEach((place) => {
      const key = `${place.id || ""}:${place.latitude}:${place.longitude}`;
      if (!seen.has(key)) {
        seen.add(key);
        places.push(place);
      }
    });
    if (places.some((place) => place.country_code === "RU")) break;
  }

  const place = places.sort((a, b) => scoreGeocodeResult(b, city) - scoreGeocodeResult(a, city))[0];
  if (!place) throw new Error("City not found. Try a city and country, like 'Moscow, Russia' or '\u041c\u043e\u0441\u043a\u0432\u0430'.");

  return fetchWeatherForPlace(place);
}

async function fetchWeatherByCoords(latitude, longitude) {
  const place = { name: "Current location", country_code: "", latitude, longitude, timezone: "auto" };
  return fetchWeatherForPlace(place);
}

async function fetchWeatherForPlace(place) {
  const weatherUrl = new URL("https://api.open-meteo.com/v1/forecast");
  weatherUrl.search = new URLSearchParams({
    latitude: String(place.latitude),
    longitude: String(place.longitude),
    current:
      "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,sunrise,sunset",
    timezone: "auto",
    forecast_days: "5",
  });

  const data = await fetchJson(weatherUrl, "Weather service is unavailable right now.");
  const [condition, description, Icon] = describeCode(data.current.weather_code);

  return {
    city: place.name,
    country: place.country_code || place.country || "",
    condition,
    description,
    icon: Icon,
    temperature: data.current.temperature_2m,
    feelsLike: data.current.apparent_temperature,
    humidity: data.current.relative_humidity_2m,
    windSpeed: data.current.wind_speed_10m,
    windDirection: data.current.wind_direction_10m,
    uvIndex: data.daily.uv_index_max?.[0],
    precipitation: data.daily.precipitation_probability_max?.[0],
    sunrise: data.daily.sunrise?.[0],
    sunset: data.daily.sunset?.[0],
    updatedAt: new Date().toISOString(),
    forecast: data.daily.time.map((day, index) => {
      const [dailyCondition, dailyDescription, DailyIcon] = describeCode(data.daily.weather_code[index]);
      return {
        day,
        condition: dailyCondition,
        description: dailyDescription,
        icon: DailyIcon,
        high: data.daily.temperature_2m_max[index],
        low: data.daily.temperature_2m_min[index],
        precipitation: data.daily.precipitation_probability_max?.[index],
      };
    }),
  };
}

function Detail({ icon: Icon, label, value }) {
  return (
    <div className="rounded-lg border border-white/20 bg-white/15 p-4 text-white shadow-sm backdrop-blur">
      <div className="flex items-center gap-2 text-white/70">
        <Icon className="h-4 w-4" />
        <span className="text-xs font-semibold uppercase tracking-wide">{label}</span>
      </div>
      <p className="mt-2 text-lg font-semibold">{value}</p>
    </div>
  );
}

export default function App() {
  const [query, setQuery] = useState(() => getStoredValue(STORAGE_KEYS.city, DEFAULT_CITY));
  const [unit, setUnit] = useState(() => getStoredValue(STORAGE_KEYS.unit, "c"));
  const [recentSearches, setRecentSearches] = useState(getStoredRecent);
  const [weather, setWeather] = useState(null);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  const background = useMemo(() => backgrounds[weather?.condition] || backgrounds.Clear, [weather]);
  const WeatherIcon = weather?.icon || CloudSun;

  async function search(city = query) {
    const trimmed = city.trim();
    if (!trimmed) return;
    setStatus("loading");
    setError("");
    try {
      const nextWeather = await fetchWeatherByCity(trimmed);
      setWeather(nextWeather);
      setQuery(trimmed);
      window.localStorage.setItem(STORAGE_KEYS.city, trimmed);
      rememberSearch(trimmed);
      setRecentSearches(getStoredRecent());
      setStatus("ready");
    } catch (err) {
      setError(err.message || "Something went wrong while loading weather.");
      setStatus("error");
    }
  }

  async function useCurrentLocation() {
    if (!navigator.geolocation) {
      setError("Location is not supported in this browser.");
      setStatus("error");
      return;
    }

    setStatus("loading");
    setError("");
    navigator.geolocation.getCurrentPosition(
      async ({ coords }) => {
        try {
          const nextWeather = await fetchWeatherByCoords(coords.latitude, coords.longitude);
          setWeather(nextWeather);
          setQuery(nextWeather.city);
          setStatus("ready");
        } catch (err) {
          setError(err.message || "Could not load weather for your location.");
          setStatus("error");
        }
      },
      () => {
        setError("Location permission was denied.");
        setStatus("error");
      }
    );
  }

  useEffect(() => {
    search(query || DEFAULT_CITY);
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.unit, unit);
    } catch {
      // Ignore storage errors; unit switching remains available for the session.
    }
  }, [unit]);

  return (
    <main className={`min-h-screen bg-gradient-to-br ${background} px-4 py-6 text-slate-950 transition-colors duration-700`}>
      <div className="mx-auto flex min-h-[calc(100vh-3rem)] w-full max-w-5xl flex-col">
        <header className="flex flex-col gap-4 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-3 text-white">
              <CloudSun className="h-9 w-9 drop-shadow" />
              <h1 className="text-3xl font-bold text-white drop-shadow sm:text-4xl">{APP_NAME}</h1>
            </div>
            <p className="mt-1 text-sm text-white/80">Saved searches, current conditions, and a 5-day outlook.</p>
          </div>
          <div className="inline-flex w-fit rounded-lg border border-white/20 bg-white/15 p-1 text-sm font-semibold text-white backdrop-blur">
            <button aria-pressed={unit === "c"} className={`rounded-md px-3 py-1.5 ${unit === "c" ? "bg-white text-slate-900" : ""}`} onClick={() => setUnit("c")}>
              {"\u00b0"}C
            </button>
            <button aria-pressed={unit === "f"} className={`rounded-md px-3 py-1.5 ${unit === "f" ? "bg-white text-slate-900" : ""}`} onClick={() => setUnit("f")}>
              {"\u00b0"}F
            </button>
          </div>
        </header>

        <section className="mt-8">
          <form
            className="flex flex-col gap-3 rounded-lg border border-white/25 bg-white/20 p-3 shadow-xl backdrop-blur sm:flex-row"
            onSubmit={(event) => {
              event.preventDefault();
              search();
            }}
          >
            <label className="relative flex-1">
              <MapPin className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" />
              <input
                className="h-12 w-full rounded-md border border-white/30 bg-white/90 pl-10 pr-3 text-base outline-none ring-sky-500 transition focus:ring-2"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search city"
              />
            </label>
            <button className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-slate-950 px-5 font-semibold text-white transition hover:bg-slate-800 disabled:opacity-60" disabled={status === "loading"}>
              {status === "loading" ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              {status === "loading" ? "Loading" : "Search"}
            </button>
            <button type="button" className="inline-flex h-12 items-center justify-center gap-2 rounded-md bg-white/90 px-4 font-semibold text-slate-900 transition hover:bg-white" onClick={useCurrentLocation}>
              <LocateFixed className="h-4 w-4" />
              Locate
            </button>
          </form>

          <div className="mt-3 flex flex-wrap gap-2">
            {[...new Set([...recentSearches, ...popularCities])].slice(0, 8).map((city) => (
              <button key={city} className="rounded-full border border-white/25 bg-white/20 px-3 py-1.5 text-sm font-medium text-white backdrop-blur transition hover:bg-white/30" onClick={() => search(city)}>
                {city}
              </button>
            ))}
          </div>
        </section>

        {error && <p className="mt-5 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{error}</p>}

        {status === "loading" && !weather && (
          <section className="mt-8 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
            <div className="min-h-64 animate-pulse rounded-lg border border-white/25 bg-white/55 p-6 shadow-xl backdrop-blur" />
            <div className="grid grid-cols-2 gap-3">
              {Array.from({ length: 6 }).map((_, index) => (
                <div key={index} className="h-24 animate-pulse rounded-lg border border-white/20 bg-white/20" />
              ))}
            </div>
          </section>
        )}

        {weather && (
          <section className="mt-8 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
            <div className="rounded-lg border border-white/25 bg-white/80 p-6 shadow-xl backdrop-blur">
              <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="flex items-center gap-2 text-sm font-semibold text-slate-500">
                    <MapPin className="h-4 w-4" />
                    {[weather.city, weather.country].filter(Boolean).join(", ")}
                  </p>
                  <h2 className="mt-3 text-7xl font-bold tracking-normal text-slate-950">{formatTemp(weather.temperature, unit)}</h2>
                  <p className="mt-2 text-xl font-semibold capitalize text-slate-700">{weather.description}</p>
                  <p className="mt-1 text-sm text-slate-500">Feels like {formatTemp(weather.feelsLike, unit)}</p>
                  <p className="mt-3 text-xs font-medium text-slate-500">Updated {formatDateTime(weather.updatedAt)}</p>
                </div>
                <div className="flex h-36 w-36 items-center justify-center rounded-full bg-sky-100 text-sky-700 shadow-inner">
                  <WeatherIcon className="h-20 w-20" strokeWidth={1.5} />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Detail icon={Droplets} label="Humidity" value={`${weather.humidity}%`} />
              <Detail icon={Wind} label="Wind" value={`${Math.round(weather.windSpeed)} km/h`} />
              <Detail icon={Sun} label="UV Index" value={Math.round(weather.uvIndex ?? 0)} />
              <Detail icon={Compass} label="Direction" value={`${Math.round(weather.windDirection ?? 0)}\u00b0`} />
              <Detail icon={Gauge} label="Rain Chance" value={`${Math.round(weather.precipitation ?? 0)}%`} />
              <Detail icon={Sunrise} label="Sunrise" value={formatTime(weather.sunrise)} />
              <Detail icon={Sunset} label="Sunset" value={formatTime(weather.sunset)} />
            </div>
          </section>
        )}

        {weather?.forecast && (
          <section className="mt-5 rounded-lg border border-white/25 bg-white/20 p-4 shadow-xl backdrop-blur">
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-white/80">5-Day Forecast</h3>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
              {weather.forecast.map((day) => {
                const DayIcon = day.icon;
                return (
                  <article key={day.day} className="rounded-lg bg-white/85 p-4 text-center shadow-sm">
                    <p className="text-sm font-bold text-slate-600">
                      {new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(new Date(`${day.day}T12:00:00`))}
                    </p>
                    <DayIcon className="mx-auto my-3 h-9 w-9 text-sky-700" strokeWidth={1.6} />
                    <p className="text-sm font-semibold text-slate-900">
                      {formatTemp(day.high, unit)} <span className="text-slate-500">{formatTemp(day.low, unit)}</span>
                    </p>
                    <p className="mt-1 text-xs font-medium text-slate-500">{Math.round(day.precipitation ?? 0)}% rain</p>
                  </article>
                );
              })}
            </div>
          </section>
        )}

        <footer className="mt-auto py-6 text-center text-xs text-white/70">
          Weather data from Open-Meteo. No API key required.
        </footer>
      </div>
    </main>
  );
}
